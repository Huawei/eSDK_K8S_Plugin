package config

const (
	DefaultNameSpace        = "huawei-csi"
	OrchestratorName        = "Huawei"
	OrchestratorVersion     = "3.0.0"
	MinKubernetesCSIVersion = "v1.21.0"
	MaxKubernetesCSIVersion = "v1.24.x"
)
